# Part 2: Fiber
